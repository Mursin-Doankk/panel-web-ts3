# Psychokillers-webinterface-moddified-for-teaspeak-master
 i finishéd working on Psychokillers webinterface modiffied( a little bit) for Teaspeak supports php 7.0 and ssl certificate
 
Supported languages:

German (de)

English (en)

Dutch (nl)

Portuguese (br) by Rennato

French (fr)

Turkish (tr) By RoTrKO

