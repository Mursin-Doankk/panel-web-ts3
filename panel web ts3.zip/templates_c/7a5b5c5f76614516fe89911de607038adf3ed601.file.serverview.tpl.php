<?php /* Smarty version Smarty3rc4, created on 2023-05-30 23:12:59
         compiled from "C:\xampp\htdocs\tea\templates/bootstrap/serverview.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1852063956647666db031a58-42538212%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7a5b5c5f76614516fe89911de607038adf3ed601' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tea\\templates/bootstrap/serverview.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '1852063956647666db031a58-42538212',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'C:\xampp\htdocs\tea\libs\Smarty\libs\plugins\modifier.date_format.php';
?><?php if (!empty($_smarty_tpl->getVariable('error')->value)||!empty($_smarty_tpl->getVariable('noerror')->value)){?>
<div class="col-md-9 col-xs-12">
    <div class="alert alert-warning">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
        <p><?php echo $_smarty_tpl->getVariable('error')->value;?>
</p>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
        <p><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</p>
	<?php }?>
    </div>
</div>
<?php }?>
<?php if ($_smarty_tpl->getVariable('newserverversion')->value!==true&&!empty($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_version'])){?>
<div class="col-md-9 col-xs-12">
    <div class="alert alert-warning">
		<?php echo $_smarty_tpl->getVariable('lang')->value['serverupdateav'];?>
<?php echo $_smarty_tpl->getVariable('newserverversion')->value;?>

    </div>
</div>
<?php }?>

<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_info_view'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_info_view'])){?>
<div class="col-md-9 col-xs-12">
    <div class="alert alert-warning">
		<?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>

    </div>
</div>
<?php }else{ ?>
<div class="col-md-9 col-xs-12">
    <div class="panel panel-default">
        <div class="panel-body">
        <div class="col-lg-12">
            <form class="form-horizontal"  method="post" action="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
                <div class="input-group">
                    <input type="text" class="form-control" name="msgtoserver" placeholder="<?php echo $_smarty_tpl->getVariable('lang')->value['msgtoserver'];?>
">
                    <input type="hidden" name="sid" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>
" />
                    <span class="input-group-btn">
                        <button class="btn btn-default" name="sendmsg" type="submit"><?php echo $_smarty_tpl->getVariable('lang')->value['send'];?>
</button>
                    </span>
                </div>
            </form>
        </div>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['virtualserver'];?>
 #<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>
</h3>
            <form method="post" action="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
                <input type="hidden" name="sid" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>
" />
                <input class="stop srv-controls" type="submit" name="stop" value="" title="<?php echo $_smarty_tpl->getVariable('lang')->value['stop'];?>
" onclick="return confirm('<?php echo $_smarty_tpl->getVariable('lang')->value['stopservermsg'];?>
')" />
            </form>
            <form method="post" action="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
                <input type="hidden" name="sid" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>
" />
                <input class="start srv-controls" type="submit" name="start" value="" title="<?php echo $_smarty_tpl->getVariable('lang')->value['start'];?>
" />
            </form>
        </div>
        <table class="table table-condensed" cellpadding="1" cellspacing="0">
            <thead>
                <tr>
                    <th colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['basics'];?>
</th>
                </tr>
            </thead>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['autostart'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_autostart']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['serveraddress'];?>
:</td>
                <td><?php echo $_SESSION['server_ip'];?>
:<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_port'];?>
</td>
            </tr>
            <tr>
                <td class="green1" style="width:50%"><?php echo $_smarty_tpl->getVariable('lang')->value['minclientversion'];?>
:</td>
                <td class="green1" style="width:50%"><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_min_client_version'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['uniqueid'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_unique_identifier'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_name'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['welcomemsg'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_welcomemessage'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['version'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_version'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['platform'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_platform'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
:</td>
                <td><?php echo smarty_modifier_date_format($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_created'],"%d.%m.%Y - %H:%M:%S");?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['status'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_status'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['runtime'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_uptime'];?>

                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_clientsonline']-$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_queryclientsonline'];?>
 / <?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_maxclients'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['queryclients'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_queryclientsonline'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['maxreservedslots'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_reserved_slots'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['showonweblist'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_weblist_enabled']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>				
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmode'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==0){?>
                <?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodeindi'];?>

                <?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==1){?>
                <?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodegoff'];?>

                <?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==2){?>
                <?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodegon'];?>

                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_channelsonline'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['minclientschan'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_min_clients_in_channel_before_forced_silence'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['clientsdimm'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_priority_speaker_dimm_modificator'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['passwordset'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_flag_password']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['securitylevel'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_needed_identity_security_level'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['iconid'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_icon_id'];?>
</td>
            </tr>
            <thead>
                <tr>
                    <th colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['standardgroups'];?>
</th>
                </tr>
            </thead>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['servergroup'];?>
:</td>
                <td>
                <?php if (!empty($_smarty_tpl->getVariable('servergroups')->value)){?>
                    <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                        <?php if ($_smarty_tpl->tpl_vars['value']->value['sgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_server_group']){?>
                            (<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
)<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

                        <?php }?>
                    <?php }} ?>
                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroup'];?>
:</td>
                <td>
                <?php if (!empty($_smarty_tpl->getVariable('channelgroups')->value)){?>
                    <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                        <?php if ($_smarty_tpl->tpl_vars['value']->value['cgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_channel_group']){?>
                            (<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
)<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

                        <?php }?>
                    <?php }} ?>
                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['chanadmingroup'];?>
:</td>
                <td>
                <?php if (!empty($_smarty_tpl->getVariable('channelgroups')->value)){?>
                    <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                        <?php if ($_smarty_tpl->tpl_vars['value']->value['cgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_channel_admin_group']){?>
                            (<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
)<?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>

                        <?php }?>
                    <?php }} ?>
                <?php }?>
                </td>
            </tr>
            <thead>
                <tr>
                    <th colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
</th>
                </tr>
            </thead>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessage'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessageshow'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']=='0'){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['nomessage'];?>

                    <?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']=='1'){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['showmessagelog'];?>

                    <?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']=='2'){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['showmodalmessage'];?>

                    <?php }elseif($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']=='3'){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['modalandexit'];?>

                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['hosturl'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_url'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerurl'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url']!=''){?>
                <img style="width:350px" src="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url'];?>
" alt="" /><br />
                <?php }?>
                <?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerintval'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_interval'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttongfx'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_gfx_url'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttontooltip'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_tooltip'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttonurl'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_url'];?>
</td>
            </tr>
            <thead>
                <tr>
                    <th colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['autoban'];?>
</th>
                </tr>
            </thead>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['autobancount'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_autoban_count'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['autobantime'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_autoban_time'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['removetime'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_remove_time'];?>
</td>
            </tr>
            <thead>
                <tr>
                    <th colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['antiflood'];?>
</th>
                </tr>
            </thead>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['pointstickreduce'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_tick_reduce'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockcmd'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_needed_command_block'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockip'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_needed_ip_block'];?>
</td>
            </tr>
            <tr>
                <td class="thead" colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['transfers'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['upbandlimit'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_max_upload_total_bandwidth'];?>
 Byte/s</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['uploadquota'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_upload_quota'];?>
 MiB</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['downbandlimit'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_max_download_total_bandwidth'];?>
 Byte/s</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['downloadquota'];?>
:</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_download_quota'];?>
 MiB</td>
            </tr>
            <thead>
                <tr>
                    <th colspan="2"><?php echo $_smarty_tpl->getVariable('lang')->value['logs'];?>
</th>
                </tr>
            </thead>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['logclient'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_client']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['logquery'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_query']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['logchannel'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_channel']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['logpermissions'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_permissions']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['logserver'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_server']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>	
                </td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['logfiletransfer'];?>
:</td>
                <td>
                <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_filetransfer']==1){?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>

                <?php }else{ ?>
                    <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>

                <?php }?>	
                </td>
            </tr>			
        </table>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
 Viewer</h3>
        </div>
        <div class="panel-body">
            <p><?php echo $_smarty_tpl->getVariable('lang')->value['tsviewpubhtml'];?>
</p>
            <textarea rows="2" cols="20" style="width:90%;height:auto;" readonly="readonly" class="text-area"><?php echo $_smarty_tpl->getVariable('pubtsview')->value;?>
</textarea>
            <div class="viewer">
                <?php echo $_smarty_tpl->getVariable('tree')->value;?>

            </div>
        </div>
    </div>
</div>
<<?php ?>?php } ?<?php ?>>
<?php }?>

