<?php /* Smarty version Smarty3rc4, created on 2023-05-30 22:19:54
         compiled from "C:\xampp\htdocs\Psychokillers\templates/bootstrap/servertraffic.tpl" */ ?>
<?php /*%%SmartyHeaderCode:153488614464765a6a550b56-56612489%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5d066495fe8b199916319108ff5d050fa7f9f28c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Psychokillers\\templates/bootstrap/servertraffic.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '153488614464765a6a550b56-56612489',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="col-md-9 col-xs-12">
<?php if (!isset($_smarty_tpl->getVariable('sid')->value)){?>
	<?php if (!isset($_GET['refresh'])||$_GET['refresh']=='on'){?>
	<meta http-equiv="refresh" content="3; URL=index.php?site=servertraffic" />
	<?php }?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['instancetraffic'];?>
</h3>
        </div>
        <table class="table" cellpadding="1" cellspacing="0">
            <thead>
                <tr>
                    <th style="width:33%"><?php echo $_smarty_tpl->getVariable('lang')->value['description'];?>
</th>
                    <th style="width:33%"><?php echo $_smarty_tpl->getVariable('lang')->value['incoming'];?>
</th>
                    <th style="width:33%"><?php echo $_smarty_tpl->getVariable('lang')->value['outgoing'];?>
</th>
                </tr>
            </thead>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['packetstransfered'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_packets_received_total'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_packets_sent_total'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['bytestransfered'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_bytes_received_total'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_bytes_sent_total'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['bandwidthlastsecond'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_bandwidth_received_last_second_total'];?>
 /s</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_bandwidth_sent_last_second_total'];?>
 /s</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['bandwidthlastminute'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_bandwidth_received_last_minute_total'];?>
 /s</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_bandwidth_sent_last_minute_total'];?>
 /s</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['filetransferbandwidth'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_filetransfer_bandwidth_received'];?>
 /s</td>
                <td><?php echo $_smarty_tpl->getVariable('hostinfo')->value['connection_filetransfer_bandwidth_sent'];?>
 /s</td>
            </tr>
            <tr>
                <td colspan="3">
                <?php if (!isset($_GET['refresh'])||$_GET['refresh']=='on'){?>
                    <a href="index.php?site=servertraffic&amp;refresh=off"><?php echo $_smarty_tpl->getVariable('lang')->value['stoprefresh'];?>
</a>
                <?php }else{ ?>
                <a href="index.php?site=servertraffic&amp;refresh=on"><?php echo $_smarty_tpl->getVariable('lang')->value['autorefresh'];?>
</a>
                <?php }?>
                </td>
            </tr>
        </table>
    </div>
<?php }else{ ?>
	<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_info_view'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_info_view'])){?>
        <div class="alert alert-warning">
            <p><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
: <?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
        </div>
	<?php }else{ ?>
	<?php if (!isset($_GET['refresh'])||$_GET['refresh']=='on'){?>
		<meta http-equiv="refresh" content="3; URL=index.php?site=servertraffic&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
" />
	<?php }?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['virtualtraffic'];?>
</h3>
        </div>
        <table class="table" cellpadding="1" cellspacing="0">
            <tr>
                <th style="width:33%"><?php echo $_smarty_tpl->getVariable('lang')->value['description'];?>
</th>
                <th style="width:33%"><?php echo $_smarty_tpl->getVariable('lang')->value['incoming'];?>
</th>
                <th style="width:33%"><?php echo $_smarty_tpl->getVariable('lang')->value['outgoing'];?>
</th>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['packetstransfered'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_packets_received_total'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_packets_sent_total'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['bytestransfered'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_bytes_received_total'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_bytes_sent_total'];?>
</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['bandwidthlastsecond'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_bandwidth_received_last_second_total'];?>
 /s</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_bandwidth_sent_last_second_total'];?>
 /s</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['bandwidthlastminute'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_bandwidth_received_last_minute_total'];?>
 /s</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_bandwidth_sent_last_minute_total'];?>
 /s</td>
            </tr>
            <tr>
                <td><?php echo $_smarty_tpl->getVariable('lang')->value['filetransferbandwidth'];?>
</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_filetransfer_bandwidth_received'];?>
 /s</td>
                <td><?php echo $_smarty_tpl->getVariable('serverinfo')->value['connection_filetransfer_bandwidth_sent'];?>
 /s</td>
            </tr>
            <tr>
                <td colspan="3">
                <?php if (!isset($_GET['refresh'])||$_GET['refresh']=='on'){?>
                <a href="index.php?site=servertraffic&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;refresh=off"><?php echo $_smarty_tpl->getVariable('lang')->value['stoprefresh'];?>
</a>
                <?php }else{ ?>
                <a href="index.php?site=servertraffic&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;refresh=on"><?php echo $_smarty_tpl->getVariable('lang')->value['autorefresh'];?>
</a>
                <?php }?>
                </td>
            </tr>
        </table>
    </div>
<?php }?>
<?php }?>
</div>