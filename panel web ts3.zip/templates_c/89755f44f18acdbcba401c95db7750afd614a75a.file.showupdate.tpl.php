<?php /* Smarty version Smarty3rc4, created on 2023-05-30 22:35:25
         compiled from "C:\xampp\htdocs\psychokiller\templates/bootstrap/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:36279626464765e0d3ef277-86549356%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '89755f44f18acdbcba401c95db7750afd614a75a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\psychokiller\\templates/bootstrap/showupdate.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '36279626464765e0d3ef277-86549356',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<tr>
	<td class="green1 warning center" colspan="2">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

	</td>
<tr>
<?php }?>