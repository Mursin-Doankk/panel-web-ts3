<?php /* Smarty version Smarty3rc4, created on 2023-05-30 22:05:09
         compiled from "C:\xampp\htdocs\Psychokillers\templates/bootstrap/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:317715453647656f5d44681-92204211%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5e9bb822f3e1c37a1e80b0f9ee0c074f3c97effe' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Psychokillers\\templates/bootstrap/showupdate.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '317715453647656f5d44681-92204211',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<tr>
	<td class="green1 warning center" colspan="2">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

	</td>
<tr>
<?php }?>