<?php /* Smarty version Smarty3rc4, created on 2023-05-30 22:08:18
         compiled from "C:\xampp\htdocs\Psychokillers\templates/bootstrap/token.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1363059582647657b2b676e9-98209469%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2fb226fbf595d15d403fc8dd880c9469969e3eae' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Psychokillers\\templates/bootstrap/token.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '1363059582647657b2b676e9-98209469',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'C:\xampp\htdocs\Psychokillers\libs\Smarty\libs\plugins\modifier.date_format.php';
?><?php if (!empty($_smarty_tpl->getVariable('error')->value)||!empty($_smarty_tpl->getVariable('noerror')->value)){?>
<div class="col-md-9 col-xs-12">
    <div class="alert alert-warning">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
        <p><?php echo $_smarty_tpl->getVariable('error')->value;?>
</p>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
        <p><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</p>
	<?php }?>
    </div>
</div>
<?php }?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_token_list'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_token_list'])){?>
    <div class="col-md-9 col-xs-12">
        <div class="alert alert-warning">
            <p><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
: <?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
        </div>
    </div>
<?php }else{ ?>
<div class="col-md-9 col-xs-12">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['tokenlist'];?>
</h3>
        </div>
        <form method="post" action="index.php?site=token&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
        <table class="table" cellspacing="0">
            <thead>
                <tr>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['token'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['id1'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['id2'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['created'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['description'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['selectall'];?>
<input type="checkbox" name="checkall" value="0" onclick="check(1)" /></th>
                </tr>
            </thead>
            <?php if (!empty($_smarty_tpl->getVariable('tokenlist')->value)){?>
                <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('tokenlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['value']->value['token'];?>
</td>
                        <td>
                        <?php if ($_smarty_tpl->tpl_vars['value']->value['token_type']==0){?>
                            <?php echo $_smarty_tpl->getVariable('lang')->value['servergroup'];?>

                            <?php }elseif($_smarty_tpl->tpl_vars['value']->value['token_type']==1){?>
                            <?php echo $_smarty_tpl->getVariable('lang')->value['channelgroup'];?>

                        <?php }?>
                        </td>
                        <td>
                        <?php if ($_smarty_tpl->tpl_vars['value']->value['token_type']==0){?>
                            <?php  $_smarty_tpl->tpl_vars['value2'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key2'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('sgrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value2']->key => $_smarty_tpl->tpl_vars['value2']->value){
 $_smarty_tpl->tpl_vars['key2']->value = $_smarty_tpl->tpl_vars['value2']->key;
?>
                                <?php if ($_smarty_tpl->tpl_vars['value2']->value['sgid']==$_smarty_tpl->tpl_vars['value']->value['token_id1']){?>
                                    <?php echo $_smarty_tpl->tpl_vars['value2']->value['name'];?>

                                <?php }?>
                            <?php }} ?>
                        <?php }elseif($_smarty_tpl->tpl_vars['value']->value['token_type']==1){?>
                            <?php  $_smarty_tpl->tpl_vars['value2'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key2'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('cgrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value2']->key => $_smarty_tpl->tpl_vars['value2']->value){
 $_smarty_tpl->tpl_vars['key2']->value = $_smarty_tpl->tpl_vars['value2']->key;
?>
                                <?php if ($_smarty_tpl->tpl_vars['value2']->value['cgid']==$_smarty_tpl->tpl_vars['value']->value['token_id1']){?>
                                    <?php echo $_smarty_tpl->tpl_vars['value2']->value['name'];?>

                                <?php }?>
                            <?php }} ?>
                        <?php }?>
                        </td>
                        <td>
                        <?php if ($_smarty_tpl->tpl_vars['value']->value['token_type']==1){?>
                            <?php  $_smarty_tpl->tpl_vars['value2'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key2'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value2']->key => $_smarty_tpl->tpl_vars['value2']->value){
 $_smarty_tpl->tpl_vars['key2']->value = $_smarty_tpl->tpl_vars['value2']->key;
?>
                                <?php if ($_smarty_tpl->tpl_vars['value2']->value['cid']==$_smarty_tpl->tpl_vars['value']->value['token_id2']){?>
                                    <?php echo $_smarty_tpl->tpl_vars['value2']->value['channel_name'];?>

                                <?php }?>
                            <?php }} ?>
                        <?php }?>
                        </td>
                        <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['token_created'],"%d.%m.%Y - %H:%M:%S");?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['value']->value['token_description'];?>
</td>
                        <td>
                        <?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_token_delete'])||$_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_token_delete']==1){?>
                        <input type="checkbox" name="token[]" value="<?php echo $_smarty_tpl->tpl_vars['value']->value['token'];?>
" />
                        <?php }?>
                        </td>
                    </tr>
                <?php }} ?> 
                <tr>
                    <td colspan="6">&nbsp;</td>
                    <td align="center"><input type="submit" name="deltoken" value="<?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
" /></td>
                </tr>
            <?php }?>
        </table>
        </form>
    </div>
<?php }?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_token_add'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_token_add'])){?>
    <div class="alert alert-warning">
            <p><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
: <?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
    </div>
</div>
<?php }else{ ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['createtoken'];?>
</h3>
        </div>
        <form method="post" action="index.php?site=token&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
        <table class="table" >
            <thead>
                <tr>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['groups'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['description'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['number'];?>
</th>
                    <th><?php echo $_smarty_tpl->getVariable('lang')->value['option'];?>
</th>
                </tr>
            </thead>
            <tr>
                <td>
                <select name="tokentype" onchange="hide_select(this.value)">
                    <option value=""><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
</option>
                    <option value="0">(0)<?php echo $_smarty_tpl->getVariable('lang')->value['servergroup'];?>
</option>
                    <option value="1">(1)<?php echo $_smarty_tpl->getVariable('lang')->value['channelgroup'];?>
</option>
                </select>
                </td>
                <td>
                <div id="groups">
                <select id="servergroups" style="display:none" name="tokenid1_1">
                <optgroup label="<?php echo $_smarty_tpl->getVariable('lang')->value['servergroups'];?>
">
                <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('sgrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                    <?php if ($_smarty_tpl->tpl_vars['value']->value['type']!=0){?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
">(<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
) <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
                    <?php }?>
                <?php }} ?>
                </optgroup>
                </select>
                <select id="channelgroups" style="display:none" name="tokenid1_2">
                <optgroup label="<?php echo $_smarty_tpl->getVariable('lang')->value['channelgroups'];?>
">
                <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('cgrouplist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                    <?php if ($_smarty_tpl->tpl_vars['value']->value['type']!=0){?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
">(<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
) <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
                    <?php }?>
                <?php }} ?>
                </optgroup>
                </select>
                </div>
                </td>
                <td>
                <select id="channel" style="display:none" name="tokenid2">
                <option value="0"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</option>
                <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
                <?php }} ?>
                </select>
                </td>
                <td>
                <input type="text" name="description" value="" />
                </td>
                <td>
                <input type="text" name="number" size="3" value="1" />
                </td>
                <td>
                <input class="button" type="submit" name="addtoken" value="<?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" />
                </td>
            </tr>
        </table>
        </form>
    </div>
</div>
<?php }?>