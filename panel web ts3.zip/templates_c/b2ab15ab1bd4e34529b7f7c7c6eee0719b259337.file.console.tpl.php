<?php /* Smarty version Smarty3rc4, created on 2023-05-31 03:47:47
         compiled from "C:\xampp\htdocs\tea\templates/bootstrap/console.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9963642786476a743d21174-30538858%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b2ab15ab1bd4e34529b7f7c7c6eee0719b259337' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tea\\templates/bootstrap/console.tpl',
      1 => 1685477065,
    ),
  ),
  'nocache_hash' => '9963642786476a743d21174-30538858',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<form method="post" action="index.php?site=console&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
<table class="border" cellpadding="0" cellspacing="0">
	<tr>
		<td class="thead"><?php echo $_smarty_tpl->getVariable('lang')->value['queryconsole'];?>
</td>
	</tr>
	<tr>
		<td><?php echo $_smarty_tpl->getVariable('lang')->value['inputbox'];?>
</td>
	</tr>
	<tr>
		<td>
			<textarea name="command" cols="50" rows="10"></textarea>	
		</td>
	</tr>
	<tr>
		<td><input class="button" type="submit" name="execute" value="<?php echo $_smarty_tpl->getVariable('lang')->value['execute'];?>
" /><br /><br /></td>
	</tr>
	<tr>
		<td><?php echo $_smarty_tpl->getVariable('lang')->value['outputbox'];?>
</td>
	</tr>
	<tr>
		<td>
			<textarea name="output" cols="80" rows="20" readonly="readonly"><?php echo $_smarty_tpl->getVariable('showOutput')->value;?>
</textarea>	
		</td>
	</tr>
</table>
</form>