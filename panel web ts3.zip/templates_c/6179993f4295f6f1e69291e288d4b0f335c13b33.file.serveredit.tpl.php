<?php /* Smarty version Smarty3rc4, created on 2023-05-30 22:06:52
         compiled from "C:\xampp\htdocs\Psychokillers\templates/bootstrap/serveredit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5371118656476575c770bb4-91759978%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6179993f4295f6f1e69291e288d4b0f335c13b33' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Psychokillers\\templates/bootstrap/serveredit.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '5371118656476575c770bb4-91759978',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!empty($_smarty_tpl->getVariable('error')->value)||!empty($_smarty_tpl->getVariable('noerror')->value)){?>
<div class="col-md-9 col-xs-12">
    <div class="alert alert-warning">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
        <p><?php echo $_smarty_tpl->getVariable('error')->value;?>
</p>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
        <p><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</p>
	<?php }?>
    </div>
</div>
<?php }?>
<div class="col-md-9 col-xs-12">
    <?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_password'])||$_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_password']==1){?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['serverpassword'];?>
</h3>
            </div>
            <div class="panel-body">
                <form class="form-horizontal" method="post" action="index.php?site=serveredit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
                <div class="form-group">
                    <label for="newpassword" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['newpassword'];?>
</label>
                    <div class="col-lg-10">
                        <input class="form-control" type="text" name="newsettings[virtualserver_password]" value=""/>
                    </div>
                </div>
                <div class="form-group">
                    <label for="option" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['option'];?>
</label>
                    <div class="col-lg-10">
                        <input class="btn btn-primary btn-sm" type="submit" name="editpw" value="<?php echo $_smarty_tpl->getVariable('lang')->value['edit'];?>
" />
                    </div>
                </div>
                </form>
            </div>
        </div>
    <?php }?>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['virtualserver'];?>
 #<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_id'];?>
 <?php echo $_smarty_tpl->getVariable('lang')->value['editor'];?>
</h3>
        </div>
        <div class="panel-body">
            <form class="form-horizontal" method="post" action="index.php?site=serveredit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
            <div class="form-group">
                <label for="autostart" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['autostart'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_autostart'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_autostart'])){?>
                        -
                    <?php }else{ ?>
                        <select class="form-control" name="newsettings[virtualserver_autostart]">
                            <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_autostart']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
                            <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_autostart']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
                        </select>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="port" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['port'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_port'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_port'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_port]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_port'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="minclientversion" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['minclientversion'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_min_client_version'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_min_client_version'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_min_client_version]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_min_client_version'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="name" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_name'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_name'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_name]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_name'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="welcomemsg" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['welcomemsg'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_welcomemessage'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_welcomemessage'])){?>
                        -
                    <?php }else{ ?>
                        <textarea class="text-area" name="newsettings[virtualserver_welcomemessage]" rows="5" style="width:100%;"><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_welcomemessage'];?>
</textarea>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="maxclients" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['maxclients'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_maxclients'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_maxclients'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_maxclients]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_maxclients'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="maxreservedslots" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['maxreservedslots'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_reserved_slots'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_reserved_slots'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_reserved_slots]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_reserved_slots'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="showonweblist" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['showonweblist'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_weblist'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_weblist'])){?>
                        -
                    <?php }else{ ?>
                        <select class="form-control" name="newsettings[virtualserver_weblist_enabled]">
                            <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_weblist_enabled']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
                            <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_weblist_enabled']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
                        </select>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="codecencryptionmode" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmode'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_codec_encryption_mode'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_codec_encryption_mode'])){?>
                        -
                    <?php }else{ ?>
                        <select class="form-control" name="newsettings[virtualserver_codec_encryption_mode]">
                        <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==0){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodeindi'];?>
</option>
                        <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==1){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodegoff'];?>
</option>
                        <option value="2" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_codec_encryption_mode']==2){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['codecencryptionmodegon'];?>
</option>
                        </select>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="passwordset" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['passwordset'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_password'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_password'])){?>
                        -
                    <?php }else{ ?>
                        <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_flag_password']==1){?><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
<?php }else{ ?> <?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
<?php }?>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="securitylevel" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['securitylevel'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_needed_identity_security_level'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_needed_identity_security_level'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_needed_identity_security_level]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_needed_identity_security_level'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="minclientschan" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['minclientschan'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_channel_forced_silence'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_channel_forced_silence'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_min_clients_in_channel_before_forced_silence]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_min_clients_in_channel_before_forced_silence'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="iconid" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['iconid'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_icon_id'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_icon_id'])){?>
                        -
                    <?php }else{ ?>
                    <div class="input-group">
                        <input class="form-control" id="iconid" type="text" name="newsettings[virtualserver_icon_id]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_icon_id'];?>
" />
                        <span class="input-group-addon" id="basic-addon2"><a href="javascript:oeffnefenster('site/showallicons.php?ip=<?php echo $_SESSION['server_ip'];?>
&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;port=<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_port'];?>
');"><?php echo $_smarty_tpl->getVariable('lang')->value['set'];?>
</a></span>
                    </div>
                    <?php }?>
                </div>
            </div>
            <hr>
            <h3><?php echo $_smarty_tpl->getVariable('lang')->value['standardgroups'];?>
</h3>
            <hr>
            <div class="form-group">
                <label for="servergroup" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['servergroup'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_servergroup'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_servergroup'])){?>
                        -
                    <?php }else{ ?>
                        <select class="form-control" name="newsettings[virtualserver_default_server_group]">
                        <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('servergroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                            <?php if ($_smarty_tpl->tpl_vars['value']->value['type']==1){?>
                                <option <?php if ($_smarty_tpl->tpl_vars['value']->value['sgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_server_group']){?>selected="selected"<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['sgid'];?>
 <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
                            <?php }?>
                        <?php }} ?>
                        </select>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="channelgroup" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroup'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_channelgroup'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_channelgroup'])){?>
                        -
                    <?php }else{ ?>
                        <select class="form-control" name="newsettings[virtualserver_default_channel_group]">
                        <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                            <?php if ($_smarty_tpl->tpl_vars['value']->value['type']==1){?>
                                <option <?php if ($_smarty_tpl->tpl_vars['value']->value['cgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_channel_group']){?>selected="selected"<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
 <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
                            <?php }?>
                        <?php }} ?>
                        </select>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="chanadmingroup" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['chanadmingroup'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_channeladmingroup'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_default_channeladmingroup'])){?>
                        -
                    <?php }else{ ?>
                        <select class="form-control" name="newsettings[virtualserver_default_channel_admin_group]">
                        <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channelgroups')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                            <?php if ($_smarty_tpl->tpl_vars['value']->value['type']==1){?>
                                <option <?php if ($_smarty_tpl->tpl_vars['value']->value['cgid']==$_smarty_tpl->getVariable('serverinfo')->value['virtualserver_default_channel_admin_group']){?>selected="selected"<?php }?> value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['cgid'];?>
 <?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
                            <?php }?>
                        <?php }} ?>
                        </select>
                    <?php }?>
                </div>
            </div>
            <hr>
            <h3><?php echo $_smarty_tpl->getVariable('lang')->value['host'];?>
</h3>
            <hr>
            <div class="form-group">
                <label for="hostmessage" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessage'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostmessage'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostmessage'])){?>
                        -
                    <?php }else{ ?>
                        <textarea class="text-area" name="newsettings[virtualserver_hostmessage]" rows="5" style="width:100%;"><?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage'];?>
</textarea>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="hostmessageshow" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['hostmessageshow'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostmessage'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostmessage'])){?>
                        -
                    <?php }else{ ?>
                    <select class="form-control" name="newsettings[virtualserver_hostmessage_mode]">
                        <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==0){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['nomessage'];?>
</option>
                        <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==1){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['showmessagelog'];?>
</option>
                        <option value="2" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==2){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['showmodalmessage'];?>
</option>
                        <option value="3" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostmessage_mode']==3){?>selected='selected'<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['modalandexit'];?>
</option>
                    </select>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="hosturl" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['hosturl'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_hostbanner_url]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_url'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="hostbannerurl" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerurl'];?>
</label>
                <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])){?>
                    <div class="col-lg-10">
                            -
                    </div>
                <?php }else{ ?>
                    <div class="col-lg-6">                        
                        <input class="form-control" type="text" name="newsettings[virtualserver_hostbanner_gfx_url]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url'];?>
" />
                    </div>
                    <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url']!=''){?>
                        <div class="col-lg-4">
                            <img style="width:350px" src="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_url'];?>
" alt="" /><br />
                        </div>
                    <?php }?>
                <?php }?>
            </div>
            <div class="form-group">
                <label for="hostbannerintval" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbannerintval'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbanner'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_hostbanner_gfx_interval]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbanner_gfx_interval'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="hostbuttontooltip" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttontooltip'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_hostbutton_tooltip]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_tooltip'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="hostbuttongfx" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttongfx'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_hostbutton_gfx_url]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_gfx_url'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="hostbuttonurl" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['hostbuttonurl'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_hostbutton'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_hostbutton_url]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_hostbutton_url'];?>
" />
                    <?php }?>
                </div>
            </div>
            <hr>
            <h3><?php echo $_smarty_tpl->getVariable('lang')->value['autoban'];?>
</h3>
            <hr>
            <div class="form-group">
                <label for="autobancount" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['autobancount'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_complain_autoban_count]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_autoban_count'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="autobantime" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['autobantime'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])){?>
                        -
                    <?php }else{ ?>
                    <div class="input-group">
                        <input class="form-control" type="text" name="newsettings[virtualserver_complain_autoban_time]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_autoban_time'];?>
" />
                        <span class="input-group-addon" id="basic-addon2"><?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>
</span>
                    </div>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="removetime" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['removetime'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_complain'])){?>
                        -
                    <?php }else{ ?>
                    <div class="input-group">
                        <input class="form-control" type="text" name="newsettings[virtualserver_complain_remove_time]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_complain_remove_time'];?>
" />
                        <span class="input-group-addon" id="basic-addon2"><?php echo $_smarty_tpl->getVariable('lang')->value['seconds'];?>
</span>
                    </div>
                    <?php }?>
                </div>
            </div>
            <hr>
            <h3><?php echo $_smarty_tpl->getVariable('lang')->value['antiflood'];?>
</h3>
            <hr>
            <div class="form-group">
                <label for="pointstickreduce" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['pointstickreduce'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_antiflood_points_tick_reduce]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_tick_reduce'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="pointsneededblockcmd" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockcmd'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_antiflood_points_needed_command_block]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_needed_command_block'];?>
" />
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="pointsneededblockip" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['pointsneededblockip'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_antiflood'])){?>
                        -
                    <?php }else{ ?>
                        <input class="form-control" type="text" name="newsettings[virtualserver_antiflood_points_needed_ip_block]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_antiflood_points_needed_ip_block'];?>
" />
                    <?php }?>
                </div>
            </div>
            <hr>
            <h3><?php echo $_smarty_tpl->getVariable('lang')->value['transfers'];?>
</h3>
            <hr>
            <div class="form-group">
                <label for="upbandlimit" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['upbandlimit'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_settings'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_settings'])){?>
                        -
                    <?php }else{ ?>
                    <div class="input-group">
                        <input class="form-control" type="text" name="newsettings[virtualserver_max_upload_total_bandwidth]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_max_upload_total_bandwidth'];?>
" />
                        <span class="input-group-addon" id="basic-addon2">byte/s</span>
                    </div>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="uploadquota" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['uploadquota'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_quotas'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_quotas'])){?>
                        -
                    <?php }else{ ?>
                    <div class="input-group">
                        <input class="form-control" type="text" name="newsettings[virtualserver_upload_quota]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_upload_quota'];?>
" />
                        <span class="input-group-addon" id="basic-addon2">MiB</span>
                    </div>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="downbandlimit" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['downbandlimit'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_settings'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_settings'])){?>
                        -
                    <?php }else{ ?>
                    <div class="input-group">
                        <input class="form-control" type="text" name="newsettings[virtualserver_max_download_total_bandwidth]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_max_download_total_bandwidth'];?>
" />
                        <span class="input-group-addon" id="basic-addon2">byte/s</span>
                    </div>
                    <?php }?>
                </div>
            </div>
            <div class="form-group">
                <label for="downloadquota" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['downloadquota'];?>
</label>
                <div class="col-lg-10">
                    <?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_quotas'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_modify_ft_quotas'])){?>
                        -
                    <?php }else{ ?>
                    <div class="input-group">
                        <input class="form-control" type="text" name="newsettings[virtualserver_download_quota]" value="<?php echo $_smarty_tpl->getVariable('serverinfo')->value['virtualserver_download_quota'];?>
" />
                        <span class="input-group-addon" id="basic-addon2">MiB</span>
                    </div>
                    <?php }?>
                </div>
            </div>
            <hr>
            <h3><?php echo $_smarty_tpl->getVariable('lang')->value['logs'];?>
</h3>
            <hr>
            <div class="form-group">
                <label for="logclient" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['logclient'];?>
</label>
                <div class="col-lg-10">
                    <select class="form-control" name="newsettings[virtualserver_log_client]">
                        <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_client']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
                        <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_client']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="logquery" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['logquery'];?>
</label>
                <div class="col-lg-10">
                    <select class="form-control" name="newsettings[virtualserver_log_query]">
                        <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_query']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
                        <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_query']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="logchannel" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['logchannel'];?>
</label>
                <div class="col-lg-10">
                    <select class="form-control" name="newsettings[virtualserver_log_channel]">
                        <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_channel']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
                        <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_channel']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="logpermissions" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['logpermissions'];?>
</label>
                <div class="col-lg-10">
                    <select class="form-control" name="newsettings[virtualserver_log_permissions]">
                        <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_permissions']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
                        <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_permissions']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="logserver" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['logserver'];?>
</label>
                <div class="col-lg-10">
                    <select class="form-control" name="newsettings[virtualserver_log_server]">
                        <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_server']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
                        <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_server']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="logfiletransfer" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['logfiletransfer'];?>
</label>
                <div class="col-lg-10">
                    <select class="form-control" name="newsettings[virtualserver_log_filetransfer]">
                        <option value="1" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_filetransfer']==1){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['yes'];?>
</option>
                        <option value="0" <?php if ($_smarty_tpl->getVariable('serverinfo')->value['virtualserver_log_filetransfer']==0){?>selected="selected"<?php }?>><?php echo $_smarty_tpl->getVariable('lang')->value['no'];?>
</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="create" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['option'];?>
</label>
                <div class="col-lg-10">
                    <input class="btn btn-primary btn-sm" type="submit" name="editserver" value="<?php echo $_smarty_tpl->getVariable('lang')->value['edit'];?>
" />
                </div>
            </div>
        </form>
        </div>
    </div>
</div>
