<?php /* Smarty version Smarty3rc4, created on 2023-05-30 22:25:44
         compiled from "C:\xampp\htdocs\Psychokillers\templates/bootstrap/head.tpl" */ ?>
<?php /*%%SmartyHeaderCode:153147358364765bc8a24ce5-30962166%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e1f824fb6b6ffe2a12ce8e611863355632ee5454' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Psychokillers\\templates/bootstrap/head.tpl',
      1 => 1685478338,
    ),
  ),
  'nocache_hash' => '153147358364765bc8a24ce5-30962166',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<main id="panel" class=" slideout-panel">
<nav class="navbar navbar-default header" id="header-menu" component="navbar">
<div class="container">
    <div class="navbar-header">
        <a class="navbar-brand" href="index.php">
            <img alt="Logo" class="page-logo" src="templates/bootstrap/gfx/images/logo.png">
			<span id="dw__title"  >  PANEL WEWE</span>
        </a>
    </div>
    <div id="nav-dropdown" class="hidden-xs">
        <ul class="nav navbar-nav navbar-right">
            <?php if ($_smarty_tpl->getVariable('loginstatus')->value===true){?>
                <li><a>Logged in as: <?php echo $_SESSION['loginuser'];?>
</a></li>
                <li><a href="index.php?site=logout"><?php echo $_smarty_tpl->getVariable('lang')->value['logout'];?>
</a></li>
            <?php }?>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <?php if ($_smarty_tpl->getVariable('fastswitch')->value==true&&$_smarty_tpl->getVariable('hoststatus')->value===true){?>
                <li><form method="get" action="index.php?site=serverview">
                    <?php if (strpos($_smarty_tpl->getVariable('site')->value,'edit')==false||$_smarty_tpl->getVariable('site')->value=='serveredit'){?>
                    <input type="hidden" name="site" value="<?php echo $_smarty_tpl->getVariable('site')->value;?>
" />
                    <?php }else{ ?>
                    <input type="hidden" name="site" value="serverview" />
                    <?php }?>
                    <select class="form-control" name="sid" onchange="submit()">
                    <?php  $_smarty_tpl->tpl_vars['server'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['server']->key => $_smarty_tpl->tpl_vars['server']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['server']->key;
?>
                        <?php if ($_smarty_tpl->getVariable('sid')->value==$_smarty_tpl->tpl_vars['server']->value['virtualserver_id']){?>
                            <option selected="selected" value="<?php echo $_smarty_tpl->tpl_vars['server']->value['virtualserver_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['server']->value['virtualserver_name'];?>
-<?php echo $_smarty_tpl->tpl_vars['server']->value['virtualserver_port'];?>
</option>
                        <?php }else{ ?>
                            <option value="<?php echo $_smarty_tpl->tpl_vars['server']->value['virtualserver_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['server']->value['virtualserver_name'];?>
-<?php echo $_smarty_tpl->tpl_vars['server']->value['virtualserver_port'];?>
</option>
                        <?php }?>
                    <?php }} ?>
                    </select>
                </form></li>
            <?php }?>
        </ul>
    </div>
</div>
</nav>
