<?php /* Smarty version Smarty3rc4, created on 2023-05-30 22:05:10
         compiled from "C:\xampp\htdocs\Psychokillers\templates/bootstrap/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1396379872647656f648e5b4-68541905%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '94bd5849e8c2e8b67e2a0eee5b0ba97053516886' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Psychokillers\\templates/bootstrap/login.tpl',
      1 => 1685477065,
    ),
  ),
  'nocache_hash' => '1396379872647656f648e5b4-68541905',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="row">
    <?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
        <div class="alert alert-warning">
            <p><?php echo $_smarty_tpl->getVariable('error')->value;?>
<p>
        </div>
    <?php }?>
    <?php if (!empty($_smarty_tpl->getVariable('motd')->value)){?>
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['motd'];?>
</h3>
                </div>
                <div class="panel-body">
                    <?php echo $_smarty_tpl->getVariable('motd')->value;?>

                </div>
            </div>
        </div>
    <?php }?>
    <?php if (!isset($_POST['sendlogin'])&&$_smarty_tpl->getVariable('loginstatus')->value!==true||$_smarty_tpl->getVariable('loginstatus')->value!==true){?>
        <div class="col-md-12">
            <div class="well well-lg">
                <form class="form-horizontal" role="form" method="post" action="index.php?site=login" id="login-form">
                    <div class="form-group">
                        <label for="server" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</label>
                        <div class="col-lg-10">
                            <?php if (count($_smarty_tpl->getVariable('instances')->value)==1){?>
                                <?php  $_smarty_tpl->tpl_vars['sdata'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['skey'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('instances')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['sdata']->key => $_smarty_tpl->tpl_vars['sdata']->value){
 $_smarty_tpl->tpl_vars['skey']->value = $_smarty_tpl->tpl_vars['sdata']->key;
?>
                                <input type="hidden" name="skey" value="<?php echo $_smarty_tpl->tpl_vars['skey']->value;?>
" />	<?php echo $_smarty_tpl->tpl_vars['sdata']->value['alias'];?>
 
                                <?php }} ?>
                            <?php }else{ ?>
                            <select class="form-control" name="skey">
                                <?php  $_smarty_tpl->tpl_vars['sdata'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['skey'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('instances')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['sdata']->key => $_smarty_tpl->tpl_vars['sdata']->value){
 $_smarty_tpl->tpl_vars['skey']->value = $_smarty_tpl->tpl_vars['sdata']->key;
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['skey']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['sdata']->value['alias'];?>
</option>	
                                <?php }} ?>
                            </select>
                            <?php }?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="username" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['username'];?>
</label>
                        <div class="col-lg-10">
                            <input class="form-control" type="text" placeholder="serveradmin" name="loginUser" id="username" value="serveradmin" autocorrect="off" autocapitalize="off" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-lg-2 control-label"><?php echo $_smarty_tpl->getVariable('lang')->value['password'];?>
</label>
                        <div class="col-lg-10">
                            <input class="form-control" type="password" placeholder="Password" name="loginPw" id="password">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-offset-2 col-lg-10">
                            <button class="btn btn-primary btn-lg btn-block" id="login" name="sendlogin" type="submit">Login</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php }?>
</div>