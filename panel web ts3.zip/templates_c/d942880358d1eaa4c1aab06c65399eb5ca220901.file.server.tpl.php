<?php /* Smarty version Smarty3rc4, created on 2023-05-30 23:10:46
         compiled from "C:\xampp\htdocs\tea\templates/bootstrap/server.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1257397443647666566c3901-60109369%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd942880358d1eaa4c1aab06c65399eb5ca220901' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tea\\templates/bootstrap/server.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '1257397443647666566c3901-60109369',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_smarty_tpl->getVariable('hoststatus')->value===false&&$_smarty_tpl->getVariable('serverhost')->value===true){?>
<div class="col-md-9 col-xs-12">
    <div class="alert alert-warning">
        <p><?php echo $_smarty_tpl->getVariable('lang')->value['nohoster'];?>
</p>>
    </div>
</div>
<?php }else{ ?>
<?php if (!empty($_smarty_tpl->getVariable('error')->value)||!empty($_smarty_tpl->getVariable('noerror')->value)){?>
<div class="col-md-9 col-xs-12">
    <div class="alert alert-warning">
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
        <p><?php echo $_smarty_tpl->getVariable('error')->value;?>
</p>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
        <p><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</p>
	<?php }?>
    </div>
</div>
<?php }?>

<div class="col-md-9 col-xs-12">
    <div class="panel panel-default">
        <div class="panel-body">
        <div class="col-lg-12">
            <form class="form-horizontal"  method="post" action="index.php?site=server">
                <div class="input-group">
                    <input type="text" class="form-control" name="msgtoall" placeholder="<?php echo $_smarty_tpl->getVariable('lang')->value['msgtoall'];?>
">
                    <span class="input-group-btn">
                        <button class="btn btn-default" name="sendmsg" type="submit"><?php echo $_smarty_tpl->getVariable('lang')->value['send'];?>
</button>
                    </span>
                </div>
            </form>
        </div>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['server'];?>
</h3>
        </div>
        <div class="panel-body">
            <?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
            <p><?php echo $_smarty_tpl->getVariable('serverstats')->value;?>
</p>
            <?php }?>
            <form method="post" name="saction" action="index.php?site=server">
            <table class="table">
                <thead>
                    <tr>
                        <th class="thead"><a class="small-sort-icon" href="index.php?site=server&amp;sortby=id&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_id'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['id'];?>
 <span class="glyphicon glyphicon-sort" aria-hidden="true"></span></a></th>
                        <th class="thead"><a class="small-sort-icon" href="index.php?site=server&amp;sortby=name&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_name'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
 <span class="glyphicon glyphicon-sort" aria-hidden="true"></span></a></th>
                        <th class="thead"><a class="small-sort-icon" href="index.php?site=server&amp;sortby=port&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_port'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['port'];?>
 <span class="glyphicon glyphicon-sort" aria-hidden="true"></span></a></th>
                        <th class="thead"><a class="small-sort-icon" href="index.php?site=server&amp;sortby=status&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_status'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['status'];?>
 <span class="glyphicon glyphicon-sort" aria-hidden="true"></span></a></th>
                        <th class="thead"><a class="small-sort-icon" href="index.php?site=server&amp;sortby=uptime&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_uptime'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['runtime'];?>
 <span class="glyphicon glyphicon-sort" aria-hidden="true"></span></a></th>
                        <th class="thead"><a class="small-sort-icon" href="index.php?site=server&amp;sortby=clients&amp;sorttype=<?php if ($_smarty_tpl->getVariable('sortby')->value=='virtualserver_clientsonline'&&$_smarty_tpl->getVariable('sorttype')->value==@SORT_ASC){?>desc<?php }else{ ?>asc<?php }?>"><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
 <span class="glyphicon glyphicon-sort" aria-hidden="true"></span></a></th>
                        <th class="thead"><?php echo $_smarty_tpl->getVariable('lang')->value['autostart'];?>
</th>
                        <th class="thead"><?php echo $_smarty_tpl->getVariable('lang')->value['options'];?>
</th>
                    </tr>
                </thead>
                <?php if (!empty($_smarty_tpl->getVariable('serverlist')->value)){?>
                    <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
</td>
                        <td><a href="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_name'];?>
</a></td>
                        <td><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_port'];?>
</td>
                        <td>
                            <?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="online"){?>
                                <span class="online"><?php echo $_smarty_tpl->getVariable('lang')->value['online'];?>
</span>
                            <?php }elseif($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="online virtual"){?>
                                <span class="onvirtual"><?php echo $_smarty_tpl->getVariable('lang')->value['onlinevirtual'];?>
</span>
                            <?php }elseif($_smarty_tpl->tpl_vars['value']->value['virtualserver_status']=="offline"){?>
                                <span class="offline"><?php echo $_smarty_tpl->getVariable('lang')->value['offline'];?>
</span>
                            <?php }?>
                        </td>
                        <td><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_uptime'];?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_clientsonline'];?>
 / <?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_maxclients'];?>
</td>
                        <td>
                            <input type="checkbox" name="caction[<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
][auto]" value="1" <?php if ($_smarty_tpl->tpl_vars['value']->value['virtualserver_autostart']==1){?>checked="checked"<?php }?>/></td>
                        <td>
                        <select class="form-control" id="caction<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
" name="caction[<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
][action]" onchange="confirmArray('<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_id'];?>
', '<?php echo addslashes($_smarty_tpl->tpl_vars['value']->value['virtualserver_name']);?>
', '<?php echo $_smarty_tpl->tpl_vars['value']->value['virtualserver_port'];?>
', '');">
                            <option value=""><?php echo $_smarty_tpl->getVariable('lang')->value['select'];?>
</option>
                            <option value="start"><?php echo $_smarty_tpl->getVariable('lang')->value['start'];?>
</option>
                            <option value="stop"><?php echo $_smarty_tpl->getVariable('lang')->value['stop'];?>
</option>
                            <option value="del"><?php echo $_smarty_tpl->getVariable('lang')->value['delete'];?>
</option>
                        </select>
                        </td>
                    </tr>
                    <?php }} ?>
                <tr>
                    <td colspan="7" align="right"></td>
                    <td>
                        <input class="btn btn-primary btn-sm srv-btn-size" type="submit" name="massaction" value="<?php echo $_smarty_tpl->getVariable('lang')->value['action'];?>
" onclick="return confirm(confirmAction())" />
                    </td>
                </tr>
                <?php }else{ ?>
                <tr>
                    <td colspan='8'><?php echo $_smarty_tpl->getVariable('lang')->value['noserver'];?>
</td>
                </tr>
                <?php }?>
            </table>
            </form>
        </div>
    </div>
</div>
<?php }?>