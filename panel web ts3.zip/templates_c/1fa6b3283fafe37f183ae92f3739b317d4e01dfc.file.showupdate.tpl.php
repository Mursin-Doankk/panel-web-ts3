<?php /* Smarty version Smarty3rc4, created on 2023-05-30 23:10:46
         compiled from "C:\xampp\htdocs\tea\templates/bootstrap/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6237370936476665600ecc1-63894978%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1fa6b3283fafe37f183ae92f3739b317d4e01dfc' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tea\\templates/bootstrap/showupdate.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '6237370936476665600ecc1-63894978',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<tr>
	<td class="green1 warning center" colspan="2">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

	</td>
<tr>
<?php }?>