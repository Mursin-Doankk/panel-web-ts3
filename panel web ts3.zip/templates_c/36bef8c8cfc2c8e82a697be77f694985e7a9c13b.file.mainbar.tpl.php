<?php /* Smarty version Smarty3rc4, created on 2023-05-30 23:10:46
         compiled from "C:\xampp\htdocs\tea\templates/bootstrap/mainbar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7392455606476665608ff81-01885539%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '36bef8c8cfc2c8e82a697be77f694985e7a9c13b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tea\\templates/bootstrap/mainbar.tpl',
      1 => 1685477066,
    ),
  ),
  'nocache_hash' => '7392455606476665608ff81-01885539',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_smarty_tpl->getVariable('loginstatus')->value===true&&$_smarty_tpl->getVariable('site')->value!=='login'){?>
<div class="col-md-3 col-xs-12">
    <div class="panel panel-default">
        <div class="panel-body">
            <ul class="nav nav-pills nav-stacked">
                <?php if ($_smarty_tpl->getVariable('hoststatus')->value===true){?>
                    <li role="presentation"><a href="index.php?site=server"><?php echo $_smarty_tpl->getVariable('lang')->value['serverlist'];?>
</a></li>
                <?php }?>
                <?php if (!isset($_smarty_tpl->getVariable('sid')->value)&&$_smarty_tpl->getVariable('hoststatus')->value===true){?>
                    <li role="presentation"><a href="index.php?site=createserver"><?php echo $_smarty_tpl->getVariable('lang')->value['createserver'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=servertraffic"><?php echo $_smarty_tpl->getVariable('lang')->value['instancetraffic'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=instanceedit"><?php echo $_smarty_tpl->getVariable('lang')->value['instanceedit'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=logview"><?php echo $_smarty_tpl->getVariable('lang')->value['logview'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=iserverbackup"><?php echo $_smarty_tpl->getVariable('lang')->value['instancebackup'];?>
</a></li>
                <?php }?>
                <?php if (isset($_smarty_tpl->getVariable('sid')->value)){?>
                    <li role="presentation"><a href="index.php?site=serverview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['serverview'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=servertraffic&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['virtualtraffic'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=serveredit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['serveredit'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=temppw&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['temppw'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=fileupload&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['iconupload'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=logview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['logview'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=filelist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['filelist'];?>
</a></li>				
                    <li role="presentation"><a href="javascript:oeffnefenster('site/interactive.php?sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;action=action');"><?php echo $_smarty_tpl->getVariable('lang')->value['massaction'];?>
</a></li>
                    <li role="presentation" class="disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['channel'];?>
</li>
                    <li role="presentation"><a href="index.php?site=channel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['channellist'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=createchannel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['createchannel'];?>
</a></li>
                    <?php if (isset($_smarty_tpl->getVariable('cid')->value)){?>
                        <li role="presentation"><a href="index.php?site=channelview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->getVariable('cid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['channelview'];?>
</a></li>
                        <li role="presentation"><a href="index.php?site=channeledit&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
&amp;cid=<?php echo $_smarty_tpl->getVariable('cid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['channeledit'];?>
</a></li>
                    <?php }?>
                    <li role="presentation" class="disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['clients'];?>
</li>
                    <li role="presentation"><a href="index.php?site=counter&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['clientcounter'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=clients&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['clientlist'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=complainlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['complainlist'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=chanclienteditperm&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['chanclientperms'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=clientcleaner&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['clientcleaner'];?>
</a></li>		
                    
                    <li role="presentation" class="disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['bans'];?>
</li>
                    <li role="presentation"><a href="index.php?site=banlist&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['banlist'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=banadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['addban'];?>
</a></li>
                    
                    <li role="presentation" class="disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['groups'];?>
</li>
                    <li role="presentation"><a href="index.php?site=sgroups&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['servergroups'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=sgroupadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['addservergroup'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=cgroups&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['channelgroups'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=cgroupadd&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['addchannelgroup'];?>
</a></li>
                    
                    <li role="presentation" class="disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['token'];?>
</li>
                    <li role="presentation"><a href="index.php?site=token&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['token'];?>
</a></li>
                    
                    <li role="presentation" class="disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['backup'];?>
</li>
                    <li role="presentation"><a href="index.php?site=backup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['chanbackups'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=serverbackup&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['serverbackups'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=permexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['permexport'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=clientsexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['clientsexport'];?>
</a></li>
                    <li role="presentation"><a href="index.php?site=bansexport&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['bansexport'];?>
</a></li>
                    
                    <li role="presentation" class="disabled"><?php echo $_smarty_tpl->getVariable('lang')->value['console'];?>
</li>
                    <li role="presentation"><a href="index.php?site=console&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
"><?php echo $_smarty_tpl->getVariable('lang')->value['queryconsole'];?>
</a></li>
                <?php }?>
            </ul>
        </div>
    </div>
</div>
<?php }?>