<?php /* Smarty version Smarty3rc4, created on 2023-05-30 22:20:01
         compiled from "C:\xampp\htdocs\Psychokillers\templates/bootstrap/logview.tpl" */ ?>
<?php /*%%SmartyHeaderCode:190340488564765a7153e027-89029658%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e10087d379f365f065b5664e78516a123c0d4efc' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Psychokillers\\templates/bootstrap/logview.tpl',
      1 => 1685477065,
    ),
  ),
  'nocache_hash' => '190340488564765a7153e027-89029658',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_log_view'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_virtualserver_log_view'])){?>
    <div class="col-md-9 col-xs-12">
        <div class="alert alert-warning">
            <p><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
: <?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</p>
        </div>
    </div>
<?php }else{ ?>
<div class="col-md-9 col-xs-12">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo $_smarty_tpl->getVariable('lang')->value['logview'];?>
</h3>
        </div>
<table class="table">
	<tr>
		<td>
			<form method="post" action="index.php?site=logview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
			<input type="hidden" name="begin_pos" value="<?php echo $_smarty_tpl->getVariable('begin_pos')->value;?>
"/>
			<input type="submit" name="showmore" value="<?php echo $_smarty_tpl->getVariable('lang')->value['showmoreentrys'];?>
" />
			</form>
		</td>
	</tr>
	<thead>
        <tr>
            <th style="width:20%"><?php echo $_smarty_tpl->getVariable('lang')->value['date'];?>
</th>
            <th style="width:5%"><?php echo $_smarty_tpl->getVariable('lang')->value['level'];?>
</th>
            <th style="width:10%"><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
</th>
            <th style="width:10%"><?php echo $_smarty_tpl->getVariable('lang')->value['serverid'];?>
</th>
            <th style="width:55%"><?php echo $_smarty_tpl->getVariable('lang')->value['message'];?>
</th>
        </tr>
    </thead>

<?php if (!empty($_smarty_tpl->getVariable('serverlog')->value)){?>
	<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('serverlog')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
		<?php if (empty($_POST['type']['error'])&&empty($_POST['type']['warning'])&&empty($_POST['type']['debug'])&&empty($_POST['type']['info'])||$_POST['type']['error']==$_smarty_tpl->tpl_vars['value']->value['level']||$_POST['type']['warning']==$_smarty_tpl->tpl_vars['value']->value['level']||$_POST['type']['debug']==$_smarty_tpl->tpl_vars['value']->value['level']||$_POST['type']['info']==$_smarty_tpl->tpl_vars['value']->value['level']){?>
			<?php if ($_smarty_tpl->getVariable('change_col')->value%2){?> <?php $_smarty_tpl->tpl_vars['td_col'] = new Smarty_variable("green1", null, null);?> <?php }else{ ?> <?php $_smarty_tpl->tpl_vars['td_col'] = new Smarty_variable("green2", null, null);?> <?php }?>
			<tr>
				<td class="<?php echo $_smarty_tpl->getVariable('td_col')->value;?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value[0];?>
</td>
				<td class="<?php echo $_smarty_tpl->getVariable('td_col')->value;?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value[1];?>
</td>
				<td class="<?php echo $_smarty_tpl->getVariable('td_col')->value;?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value[2];?>
</td>
				<td class="<?php echo $_smarty_tpl->getVariable('td_col')->value;?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value[3];?>
</td>
				<td class="<?php echo $_smarty_tpl->getVariable('td_col')->value;?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value[4];?>
</td>
			</tr>
		
			<?php $_smarty_tpl->tpl_vars['change_col'] = new Smarty_variable(($_smarty_tpl->getVariable('change_col')->value+1), null, null);?>
		<?php }?>
	<?php }} ?>
<?php }?>
	<tr>
		<td>
			<form method="post" action="index.php?site=logview&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
			<input type="hidden" name="begin_pos" value="<?php echo $_smarty_tpl->getVariable('begin_pos')->value;?>
"/>
			<input type="submit" name="showmore" value="<?php echo $_smarty_tpl->getVariable('lang')->value['showmoreentrys'];?>
" />
			</form>
		</td>
	</tr>
</table>
    </div>
</div>
<?php }?>