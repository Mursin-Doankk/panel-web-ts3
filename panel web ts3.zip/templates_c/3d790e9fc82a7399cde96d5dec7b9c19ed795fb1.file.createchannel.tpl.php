<?php /* Smarty version Smarty3rc4, created on 2023-05-31 03:47:09
         compiled from "C:\xampp\htdocs\tea\templates/bootstrap/createchannel.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6445922546476a71de99c57-27565884%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3d790e9fc82a7399cde96d5dec7b9c19ed795fb1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\tea\\templates/bootstrap/createchannel.tpl',
      1 => 1685477065,
    ),
  ),
  'nocache_hash' => '6445922546476a71de99c57-27565884',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_permanent'])&&isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_semi_permanent'])&&isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_temporary'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_permanent'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_semi_permanent'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_temporary'])){?>
	<table class="border" style="width:50%;" cellpadding="1" cellspacing="0">
		<tr>
			<td class="thead"><?php echo $_smarty_tpl->getVariable('lang')->value['error'];?>
</td>
		</tr>
		<tr>
			<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['nopermissions'];?>
</td>
		</tr>
	</table>
<?php }else{ ?>
<?php if (!empty($_smarty_tpl->getVariable('error')->value)||!empty($_smarty_tpl->getVariable('noerror')->value)){?>
<table>
	<?php if (!empty($_smarty_tpl->getVariable('error')->value)){?>
	<tr>
		<td class="error"><?php echo $_smarty_tpl->getVariable('error')->value;?>
</td>
	</tr>
	<?php }?>
	<?php if (!empty($_smarty_tpl->getVariable('noerror')->value)){?>
	<tr>
		<td class="noerror"><?php echo $_smarty_tpl->getVariable('noerror')->value;?>
</td>
	</tr>
	<?php }?>
</table>
<?php }?>
<form method="post" action="index.php?site=createchannel&amp;sid=<?php echo $_smarty_tpl->getVariable('sid')->value;?>
">
<table class="border" cellpadding="1" cellspacing="0">
			<tr>
				<td colspan="2" class="thead"><?php echo $_smarty_tpl->getVariable('lang')->value['createachannel'];?>
</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['pid'];?>
:</td>
				<td class="green1">
				<select name="settings[cpid]">
					<option value="0"><?php echo $_smarty_tpl->getVariable('lang')->value['mainchannel'];?>
</option>
					<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('channellist')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if (count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
					<option value="<?php echo $_smarty_tpl->tpl_vars['value']->value['cid'];?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['channel_name'];?>
</option>
					<?php }} ?>
				</select>
				</td>
			</tr>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['name'];?>
:</td>
				<td class="green2"><input type="text" name="settings[channel_name]" value="" /></td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['topic'];?>
:</td>
				<td class="green1">
				<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_topic'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_topic'])){?>
					-
				<?php }else{ ?>
					<input type="text" name="settings[channel_topic]" value="" />
				<?php }?>
				</td>
			</tr>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['description'];?>
:</td>
				<td class="green2">
				<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_description'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_description'])){?>
					-
				<?php }else{ ?>
					<input type="text" name="settings[channel_description]" value="" />
				<?php }?>
				</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['codec'];?>
:</td>
				<td class="green1">
				<select name="settings[channel_codec]">
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex8'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex8']==1){?>
					<option value="0"><?php echo $_smarty_tpl->getVariable('lang')->value['codec0'];?>
</option>
				<?php }?>
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex16'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex16']==1){?>
					<option value="1"><?php echo $_smarty_tpl->getVariable('lang')->value['codec1'];?>
</option>
				<?php }?>
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex32'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_speex32']==1){?>
				<option value="2"><?php echo $_smarty_tpl->getVariable('lang')->value['codec2'];?>
</option>
				<?php }?>
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_celtmono48'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_celtmono48']==1){?>
					<option value="3"><?php echo $_smarty_tpl->getVariable('lang')->value['codec3'];?>
</option>
				<?php }?>
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_opusvoice'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_opusvoice']==1){?>
					<option value="3"><?php echo $_smarty_tpl->getVariable('lang')->value['codec4'];?>
</option>
				<?php }?>
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_opusmusic'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_modify_with_codec_opusmusic']==1){?>
					<option value="3"><?php echo $_smarty_tpl->getVariable('lang')->value['codec5'];?>
</option>
				<?php }?>
				</select>
				</td>
			</tr>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['codecquality'];?>
:</td>
				<td class="green2">
				<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['i_channel_create_modify_with_codec_maxquality'])&&empty($_smarty_tpl->getVariable('permoverview')->value['i_channel_create_modify_with_codec_maxquality'])){?>
					-
				<?php }else{ ?>
					<select name="settings[channel_codec_quality]">
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					</select>
				<?php }?>
				</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['maxclients'];?>
:</td>
				<td class="green1">
				<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxclients'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxclients'])){?>
					-
				<?php }else{ ?>
					<input type="text" name="settings[channel_maxclients]" value="-1" />
				<?php }?>
				</td>
			</tr>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['maxfamilyclients'];?>
:</td>
				<td class="green2">
				<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxfamilyclients'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxfamilyclients'])){?>
					-
				<?php }else{ ?>
					<input type="text" name="settings[channel_maxfamilyclients]" value="-1" />
				<?php }?>
				</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['type'];?>
:</td>
				<td class="green1">
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_semi_permanent'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_semi_permanent']==1){?>
					<?php echo $_smarty_tpl->getVariable('lang')->value['semipermanent'];?>
 <input type="radio" name="chantyp" value="1" checked="checked" /><br/>
				<?php }?>
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_permanent'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_permanent']==1){?>
					<?php echo $_smarty_tpl->getVariable('lang')->value['permanent'];?>
 <input type="radio" name="chantyp" value="2" /><br />
				<?php }?>
				<?php if (!isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_default'])||$_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_default']==1){?>
					<?php echo $_smarty_tpl->getVariable('lang')->value['default'];?>
 <input type="radio" name="chantyp" value="3" />
				<?php }?>
				</td>
			</tr>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['maxfamilyclientsinherited'];?>
:</td>
				<td class="green2">
				<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxclients'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_maxclients'])){?>
					-
				<?php }else{ ?>
					<select name="settings[channel_flag_maxfamilyclients_inherited]">
					<option value="0">0</option>
					<option value="1">1</option>
					</select>
				<?php }?>
				</td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['neededtalkpower'];?>
:</td>
				<td class="green1">
				<?php if (isset($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_needed_talk_power'])&&empty($_smarty_tpl->getVariable('permoverview')->value['b_channel_create_with_needed_talk_power'])){?>
					-
				<?php }else{ ?>
					<input type="text" name="settings[channel_needed_talk_power]" value="0" />
				<?php }?>
				</td>
			</tr>
			<tr>
				<td class="green2"><?php echo $_smarty_tpl->getVariable('lang')->value['phoneticname'];?>
:</td>
				<td class="green2"><input type="text" name="settings[channel_name_phonetic]" value="" /></td>
			</tr>
			<tr>
				<td class="green1"><?php echo $_smarty_tpl->getVariable('lang')->value['option'];?>
:</td>
				<td class="green1"><input type="submit" name="createchannel" value="<?php echo $_smarty_tpl->getVariable('lang')->value['create'];?>
" /></td>
			</tr>
		</table>
		</form>
<?php }?>